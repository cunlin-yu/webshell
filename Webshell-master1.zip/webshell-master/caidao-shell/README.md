这个是菜刀一句话客户端集合，如需要标准的，菜刀工具里是自带的。

需要菜刀原程序的请自行百度 or google

还有一点就是  菜刀最后的版本是caidao-20111116  

    zip压缩包的md5: 04A4980C9E86B5BA267F8E55CEAC2119

"一句话"的艺术——简单的编码和变形绕过检测 url: http://drops.wooyun.org/tips/839
