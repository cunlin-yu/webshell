Ani-Shell v1.5 (Final)
    by lionaneesh

Note: Ani-Shell was intended to be used for Demonstration and Learning Purposes only,
Author is not responsible for any damage it may cause and user holds full responsibility
of his/her actions. 

==[0x00] Introduction

Ani-Shell is a simple PHP shell with some unique features like Mass Mailer ,
A simple Web-Server Fuzzer , Dosser, Back Connect , Bind Shell, Back Connect, Auto Rooter etc.
This shell has immense capabilities and have been written with some coding standards in mind
for better editing and customization.

====[0x001] Customization

1. Email Trace back is set to Off as default and emails will not be sent , If you are setting
This feature on make sure you change the default email address (lionaneesh@gmail.com) to Your email
Address, Please Change it before using.

2. Username and Passwords are set to lionaneesh and lionaneesh respectively, please change them for better security.

3. As default Lock Mode is set to on! This should not be change unless you want your shell exposed.

4. As default the Anti-Crawler Feature is set to "off" ! Change it to "on" for anti-crawler support , and longer Shell life!

5. A variable named greetings can be changed to change the Shell's greeting message.

====[0x0001] Support

[0x0001C] Official Page (https://www.facebook.com/pages/Ani-Shell/262601177097339)

====[0x0002] Default Login

Username : lionaneesh
Password : lionaneesh

==[0x01] Features

[0x01A] Shell
[0x01B] Platform Independent
[0x01C]	Mass - Mailer
[0x01D]	Small Web-Server Fuzzer
[0x01E] Dosser
[0x01F] Design
[0x02A] Secure Login
[0x02B] Deletion of Files
[0x02C] Bind Shell
[0x02D] Back Connect
[0x02E] Fixed Some Coding errors!
[0x02F] Rename Files
[0x03A] Encoded Title
[0x03B] Traceback (Email Alerts)
[0x03C] PHP Evaluate
[0x03D] Better Command Execution (even supports older version of PHP)
[0x03E] Mass Code Injector (Appender and Overwinter)
[0x03F] Lock Mode Customization
[0x04A] Mail Bomber (With Less Spam detection feature)
[0x04B] PHP Decoder
[0x04C] Anti-Crawler Feature
[0x04D] MD5 Hash Cracker
[0x04E] Python Bind-Shell

=============[0x0101] New in this version

[0x0101A] Intelligent File Manager
[0x0101A] Auto Rooter
[0x0101A] PHP Obfuscate
