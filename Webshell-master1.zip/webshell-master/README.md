﻿webshell
========
这是一个webshell收集项目

送人玫瑰，手有余香，如果各位下载了本项目，也请您能提交shell

本项目涵盖各种常用脚本

如：asp,aspx,php,jsp,pl,py

如提交各种webshell，请勿更改名称和密码

注意：所有shell 本人不保证是否有后门，但是自己上传的绝不会故意加后门

各位提交的，也请勿加后门

如发现存在后门代码，请issues 。

本项目提供的工具，禁止从事非法活动，此项目，仅供测试，所造成的一切后果，与本人无关。

Author：tennc

http://tennc.github.io/webshell

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-nc-sa/3.0/80x15.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/">Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License</a>.
<p>
<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/deed.zh"><img alt="知识共享许可协议" style="border-width:0" src="http://i.creativecommons.org/l/by-nc-sa/3.0/80x15.png" /></a><br />本作品采用<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/deed.zh">知识共享署名-非商业性使用-相同方式共享 3.0 未本地化版本许可协议</a>进行许可。

## Download link
Check github releases. Latest:

[https://github.com/tennc/webshell/releases](https://github.com/tennc/webshell/releases)
