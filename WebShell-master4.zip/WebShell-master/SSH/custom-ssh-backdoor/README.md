SSH Backdoor using Paramiko

Example:

![](print.png)