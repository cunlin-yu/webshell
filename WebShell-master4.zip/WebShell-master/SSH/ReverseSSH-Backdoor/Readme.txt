This is derived from InfosecInstitute.
Requires Paramiko Lib at both Ends. 
More Information Here: http://resources.infosecinstitute.com/creating-undetectable-custom-ssh-backdoor-python-z/