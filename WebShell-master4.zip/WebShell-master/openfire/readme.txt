上传压缩包插件
WebShell：http://localhost/plugins/test/cmd.jsp 密码023
